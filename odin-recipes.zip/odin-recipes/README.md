# odin-recipes
This is the start of my journey with The odin project i will be creating projects from odin and anyone who wants to see can do so
